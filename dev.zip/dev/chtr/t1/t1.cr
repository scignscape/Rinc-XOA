
,x u1
\x 5 

)prn >> x + 6







